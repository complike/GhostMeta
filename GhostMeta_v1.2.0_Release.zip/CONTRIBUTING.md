# Contributing

Ground Rules:
- Keine GhostEngine‑Interna veröffentlichen
- Keine Binärdateien committen
- Keine Netzwerkzugriffe
- Deterministischer C‑Code

Bug Reports:
- Version / Commit
- OS / Architektur
- Input‑Datei
- Erwartetes vs. tatsächliches Verhalten

Feature Requests:
- Problem
- Use‑Case
- Format‑Scope
- Forensik‑Relevanz

Coding Style:
- C11
- src/core, src/formats, src/forensic strikt trennen
- Header in include/

Pull Requests:
- make muss fehlerfrei laufen
- PR‑Template nutzen
