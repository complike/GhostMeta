# GhostMeta v1.2
High-performance JPEG metadata removal & forensic documentation
by Bülent Deniz (COMPLIKE)

---


# GhostMeta v1.2

High-performance JPEG metadata removal and forensic documentation  
by Bülent Deniz (COMPLIKE)

---


## Platform Notice

GhostMeta v1.2 runs only on Apple Silicon (M1–M4).  
Intel Macs, Windows, Linux and virtualization (Rosetta, WSL, Docker, QEMU) are not supported.

---


## Overview

GhostMeta v1.2 is a scientific JPEG metadata-removal and forensic-documentation tool optimized for M-series Apple Silicon.  
It removes all metadata, preserves the pixel stream exactly, and generates detailed forensic-style reports (JSON + TXT) including:

- Segment Matrix (Before/After)
- Payload sizes per segment
- SHA-256 hashes (input and output)
- Integrity hex anchors (Head, Tail, Post-EOI)
- Audit log (ISO-8601)

GhostMeta is a standalone ARM64 binary with zero external dependencies and integrates the proprietary GhostEngine v40 (4096-bit ARM-NEON).

---


## Supported Platforms


### Fully Supported
- macOS 14+ (Sonoma, Sequoia)
- Apple Silicon:
  - M4 Pro / M4 Max (recommended)
  - M3 Pro / M3 Max
  - M2 Pro / M2 Max

### Partially Supported
- M1 / M1 Pro / M1 Max (reduced NEON throughput)

### Not Supported
- Intel Macs
- Windows
- Linux
- x86_64 CPUs
- Virtualization layers (Rosetta, WSL, Docker, QEMU)

---


## Features

- Full JPEG metadata removal (EXIF, XMP, IPTC, C2PA, JUMBF, COM, Post-EOI)
- Pixel-perfect JPEG rebuild
- Scientific Segment Matrix (Before/After)
- Payload size reporting
- SHA-256 hashing
- Integrity hex anchors
- Dual forensic reports:
  - *.forensic.json
  - *.forensic.txt
- Audit log (*.audit.json)
- Zero-dependency standalone binary
- GhostEngine v40 (4096-bit NEON)

---


## Installation


### Requirements
- macOS 14+
- Apple Silicon (M1–M4)
- Xcode Command Line Tools (clang, make)
- libghostengine.a (included in repository)

### Build
git clone https://github.com/yourname/GhostMeta.git  
cd GhostMeta  
make

The binary will be created in:
dist/ghostmeta

---


## Quick Start

./ghostmeta --in photo.jpg --out clean.jpg

---


## Output Files


| File | Description |
|------|-------------|
| clean.jpg | Metadata-free JPEG |
| photo.jpg.forensic.json | Machine-readable forensic report |
| photo.jpg.forensic.txt | Human-readable forensic report |
| photo.jpg.audit.json | Short audit log |

---


## Example Forensic Report (Excerpt)

"segments": {
  "exif": {
    "status_before": "DETECTED",
    "status_after": "REMOVED",
    "size_bytes": 1234
  },
  "xmp": {
    "status_before": "NOT_PRESENT",
    "status_after": "NOT_PRESENT",
    "size_bytes": 0
  }
}

---


## CLI Options

--in <file>      Input JPEG file  
--out <file>     Output cleaned JPEG file  
--help           Show help  

---


## Exit Codes

0   Success  
1   General error  
2   Unsupported format (not JPEG)  
3   I/O error  
4   Invalid arguments  

---


## Troubleshooting


### "GhostMeta cannot be opened"
Gatekeeper blocked the binary.  
Fix:  
chmod +x ghostmeta  
xattr -c ghostmeta

### "Bad CPU type"
You are on an Intel Mac. This platform is not supported.

### "Segmentation fault"
Usually caused by corrupted JPEG input.  
Try another file.

---


## Architecture Overview


src/core/        Core logic (audit, shred, main, engine integration)  
src/formats/jpg/ JPEG parser v6 and rebuild module  
src/forensic/    JSON and TXT forensic report generators  
include/         Public headers  
dist/            Compiled binary  
app/             macOS App bundle (optional GUI wrapper)  
docs/            Blueprints, status reports, SDK documentation  
archive/         Snapshots, exports, backups  

Pipeline:

1. Input read  
2. JPEG validation  
3. Segment scan (Parser v6)  
4. Metadata extraction  
5. Clean JPEG rebuild  
6. Payload size calculation  
7. SHA-256 hashing  
8. Hex anchor generation  
9. JSON and TXT forensic reports  
10. Audit log  
11. RAM cleanup  

---


## License

- GhostMeta source code: GNU General Public License v3.0  
- GhostEngine v40 binary: proprietary, statically linked, not covered by GPL  

See LICENSE for details.

---


## Contact

For research, forensic collaboration, or licensing inquiries:  
COMPLIKE – Bülent Deniz

---

© 2026 COMPLIKE – Bülent Deniz
GhostMeta source code: GPLv3
GhostEngine v40 binary: proprietary
