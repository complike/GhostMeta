#!/bin/bash

INPUT="_GHOSTMETA_README.txt"
OUTPUT="README.md"

if [ ! -f "$INPUT" ]; then
  echo "Input file not found: $INPUT"
  exit 1
fi

cat "$INPUT" > "$OUTPUT"

echo "README.md created successfully."
