# Security Policy

Supported Versions:
Nur die aktuelle Version wird unterstützt.

Reporting:
Bitte KEINE Sicherheitslücken öffentlich posten.
Nutze GitHub → Security → Private Vulnerability Reporting.

Scope:
GhostMeta ist Open Source.
GhostEngine ist proprietär und hat eigene Sicherheitsprozesse.

Anti‑Forensics Hinweis:
GhostMeta darf nicht für illegale Zwecke genutzt werden.
