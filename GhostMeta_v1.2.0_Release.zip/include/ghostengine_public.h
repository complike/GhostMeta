#ifndef GHOSTENGINE_PUBLIC_H
#define GHOSTENGINE_PUBLIC_H

#include <stddef.h>
#include <stdint.h>

void ghost_shred(
    const uint8_t *input,
    size_t input_len,
    uint8_t **shell_buf,
    size_t *shell_len,
    uint8_t **key_buf,
    size_t *key_len
);

void ghost_secure_bzero(void *ptr, size_t len);

void ghost_shred_neon(
    const uint8_t *input,
    size_t input_len,
    uint8_t **shell_buf,
    size_t *shell_len,
    uint8_t **key_buf,
    size_t *key_len
);

#endif
