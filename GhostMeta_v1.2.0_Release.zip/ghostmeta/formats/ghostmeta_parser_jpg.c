#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "ghostmeta.h"

static void append_meta_segment(uint8_t **meta_buf, size_t *meta_pos, size_t *meta_cap, const uint8_t *seg, size_t seg_len) {
    if (!seg || seg_len == 0) return;
    if (*meta_pos + seg_len > *meta_cap) {
        size_t new_cap = (*meta_cap == 0) ? (seg_len * 2) : (*meta_cap * 2 + seg_len);
        uint8_t *tmp = realloc(*meta_buf, new_cap);
        if (!tmp) return;
        *meta_buf = tmp;
        *meta_cap = new_cap;
    }
    memcpy(*meta_buf + *meta_pos, seg, seg_len);
    *meta_pos += seg_len;
}

static int marker_no_length(uint8_t m) {
    if (m >= 0xD0 && m <= 0xD7) return 1;
    if (m == 0x01) return 1;
    return 0;
}

static int is_jumbf_magic(const uint8_t *p, size_t n) {
    if (n < 4) return 0;
    if (!memcmp(p, "jumb", 4)) return 1;
    if (!memcmp(p, "jumd", 4)) return 1;
    if (!memcmp(p, "c2pa", 4)) return 1;
    if (!memcmp(p, "cbor", 4)) return 1;
    return 0;
}

static int find_jumbf_magic_anywhere(const uint8_t *p, size_t n) {
    if (!p || n < 4) return 0;
    for (size_t i = 0; i + 4 <= n; i++) {
        if (is_jumbf_magic(p + i, n - i)) return 1;
    }
    return 0;
}

int ghostmeta_extract_jpg_metadata(
    const uint8_t *data,
    size_t size,
    uint8_t **meta_blob,
    size_t *meta_size,
    uint8_t **clean_jpg,
    size_t *clean_size,
    ghostmeta_segment_info_t *seginfo
) {
    *meta_blob  = NULL;
    *meta_size  = 0;
    *clean_jpg  = NULL;
    *clean_size = 0;

    if (seginfo) memset(seginfo, 0, sizeof(*seginfo));
    if (!data || size < 4) return -1;
    if (data[0] != 0xFF || data[1] != 0xD8) return -1;

    uint8_t *out = malloc(size);
    if (!out) return -1;

    uint8_t *meta = NULL;
    size_t meta_pos = 0, meta_cap = 0;
    size_t out_pos = 0;
    size_t i = 0;

    out[out_pos++] = data[i++];
    out[out_pos++] = data[i++];

    int seen_sos = 0;

    while (i + 1 < size) {
        if (seen_sos) {
            out[out_pos++] = data[i++];
            continue;
        }

        if (data[i] != 0xFF) {
            if (seginfo) {
                seginfo->post_eoi_before = GM_SEG_PRESENT;
                seginfo->post_eoi_after  = GM_SEG_CLEAN;
                seginfo->post_eoi_size   = size - i;
            }
            append_meta_segment(&meta, &meta_pos, &meta_cap, &data[i], size - i);
            break;
        }

        size_t ff_start = i;
        while (i < size && data[i] == 0xFF) i++;
        if (i >= size) break;

        uint8_t marker = data[i++];

        if (marker == 0xD9) {
            out[out_pos++] = 0xFF;
            out[out_pos++] = 0xD9;
            break;
        }

        if (marker_no_length(marker)) {
            out[out_pos++] = 0xFF;
            out[out_pos++] = marker;
            continue;
        }

        if (i + 1 >= size) break;
        uint16_t seg_len = (uint16_t)((data[i] << 8) | data[i + 1]);
        size_t seg_start = i - 2;
        size_t seg_total = (size_t)seg_len + 2;
        if (seg_start + seg_total > size) break;

        const uint8_t *seg = &data[seg_start];

        int is_app = (marker >= 0xE0 && marker <= 0xEF);
        int is_com = (marker == 0xFE);
        int keep = 1;

        int is_jfif = 0;
        if (marker == 0xE0 && seg_len >= 7) {
            if (seg[4]=='J' && seg[5]=='F' && seg[6]=='I' && seg[7]=='F' && seg[8]==0x00)
                is_jfif = 1;
        }

        int is_exif = 0, is_xmp = 0, is_iptc = 0, is_c2pa = 0, is_jumbf = 0;

        if (marker == 0xE1 && seg_len >= 8) {
            if (!memcmp(seg + 4, "Exif\0\0", 6)) is_exif = 1;
            else if (!memcmp(seg + 4, "http://ns.adobe.com/xap/1.0/", 29)) is_xmp = 1;
        }

        if (marker == 0xED && seg_len >= 14) {
            if (!memcmp(seg + 4, "Photoshop 3.0", 13)) is_iptc = 1;
        }

        if (marker == 0xEB && seg_len > 4) {
            const uint8_t *payload = seg + 4;
            size_t payload_len = seg_len - 2;
            if (find_jumbf_magic_anywhere(payload, payload_len)) {
                is_c2pa = 1;
                is_jumbf = 1;
            }
        }

        if (is_app && !is_jfif) keep = 0;
        if (is_com) keep = 0;
        if (is_c2pa || is_jumbf) keep = 0;

        if (!keep) {
            append_meta_segment(&meta, &meta_pos, &meta_cap, seg, seg_total);

            if (seginfo) {
                if (is_exif) {
                    seginfo->exif_before = GM_SEG_PRESENT;
                    seginfo->exif_after  = GM_SEG_CLEAN;
                    seginfo->exif_size  += seg_total;
                } else if (is_xmp) {
                    seginfo->xmp_before = GM_SEG_PRESENT;
                    seginfo->xmp_after  = GM_SEG_CLEAN;
                    seginfo->xmp_size  += seg_total;
                } else if (is_iptc) {
                    seginfo->iptc_before = GM_SEG_PRESENT;
                    seginfo->iptc_after  = GM_SEG_CLEAN;
                    seginfo->iptc_size  += seg_total;
                } else if (is_c2pa || is_jumbf) {
                    seginfo->c2pa_before  = GM_SEG_PRESENT;
                    seginfo->c2pa_after   = GM_SEG_CLEAN;
                    seginfo->c2pa_size   += seg_total;
                    seginfo->jumbf_before = GM_SEG_PRESENT;
                    seginfo->jumbf_after  = GM_SEG_CLEAN;
                    seginfo->jumbf_size  += seg_total;
                } else if (is_com) {
                    seginfo->com_before = GM_SEG_PRESENT;
                    seginfo->com_after  = GM_SEG_CLEAN;
                    seginfo->com_size  += seg_total;
                }
            }

            i = seg_start + seg_total;
            continue;
        }

        memcpy(out + out_pos, seg, seg_total);
        out_pos += seg_total;
        i = seg_start + seg_total;

        if (seginfo) {
            if (is_exif && seginfo->exif_before == 0) {
                seginfo->exif_before = GM_SEG_PRESENT;
                seginfo->exif_after  = GM_SEG_KEEP;
                seginfo->exif_size  += seg_total;
            } else if (is_xmp && seginfo->xmp_before == 0) {
                seginfo->xmp_before = GM_SEG_PRESENT;
                seginfo->xmp_after  = GM_SEG_KEEP;
                seginfo->xmp_size  += seg_total;
            } else if (is_iptc && seginfo->iptc_before == 0) {
                seginfo->iptc_before = GM_SEG_PRESENT;
                seginfo->iptc_after  = GM_SEG_KEEP;
                seginfo->iptc_size  += seg_total;
            } else if (is_c2pa && seginfo->c2pa_before == 0) {
                seginfo->c2pa_before = GM_SEG_PRESENT;
                seginfo->c2pa_after  = GM_SEG_KEEP;
                seginfo->c2pa_size  += seg_total;
            } else if (is_jumbf && seginfo->jumbf_before == 0) {
                seginfo->jumbf_before = GM_SEG_PRESENT;
                seginfo->jumbf_after  = GM_SEG_KEEP;
                seginfo->jumbf_size  += seg_total;
            } else if (is_com && seginfo->com_before == 0) {
                seginfo->com_before = GM_SEG_PRESENT;
                seginfo->com_after  = GM_SEG_KEEP;
                seginfo->com_size  += seg_total;
            }
        }

        if (marker == 0xDA) seen_sos = 1;
    }

    if (seginfo) {
        if (seginfo->exif_before == 0)  seginfo->exif_before  = GM_SEG_NO;
        if (seginfo->xmp_before == 0)   seginfo->xmp_before   = GM_SEG_NO;
        if (seginfo->iptc_before == 0)  seginfo->iptc_before  = GM_SEG_NO;
        if (seginfo->c2pa_before == 0)  seginfo->c2pa_before  = GM_SEG_NO;
        if (seginfo->jumbf_before == 0) seginfo->jumbf_before = GM_SEG_NO;
        if (seginfo->com_before == 0)   seginfo->com_before   = GM_SEG_NO;
        if (seginfo->post_eoi_before == 0) seginfo->post_eoi_before = GM_SEG_NO;

        if (seginfo->exif_after == 0)   seginfo->exif_after   = GM_SEG_NO;
        if (seginfo->xmp_after == 0)    seginfo->xmp_after    = GM_SEG_NO;
        if (seginfo->iptc_after == 0)   seginfo->iptc_after   = GM_SEG_NO;
        if (seginfo->c2pa_after == 0)   seginfo->c2pa_after   = GM_SEG_NO;
        if (seginfo->jumbf_after == 0)  seginfo->jumbf_after  = GM_SEG_NO;
        if (seginfo->com_after == 0)    seginfo->com_after    = GM_SEG_NO;
        if (seginfo->post_eoi_after == 0) seginfo->post_eoi_after = GM_SEG_NO;
    }

    *clean_jpg  = out;
    *clean_size = out_pos;

    if (meta_pos == 0) {
        free(meta);
        *meta_blob = NULL;
        *meta_size = 0;
    } else {
        *meta_blob = meta;
        *meta_size = meta_pos;
    }

    return 0;
}
