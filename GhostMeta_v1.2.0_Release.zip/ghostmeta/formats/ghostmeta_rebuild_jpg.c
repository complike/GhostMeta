#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/*
 * GhostMeta – JPG Rebuild (maximal defensiv)
 *
 * Ziel:
 *  - Den von ghostmeta_extract_jpg_metadata erzeugten clean_jpg-Buffer
 *    als stabile, möglichst robuste JPG-Datei schreiben.
 *  - Struktur prüfen:
 *      * SOI vorhanden?
 *      * SOS vorhanden?
 *      * EOI vorhanden?
 *  - Falls möglich:
 *      * fehlendes EOI ergänzen
 *      * offensichtliche Truncation erkennen
 *  - Keine Metadaten hinzufügen, nichts „reparieren“, was Meta wäre.
 *
 * Wichtig:
 *  - Wir vertrauen dem Parser, aber wir verifizieren trotzdem die Basisstruktur.
 *  - Wenn etwas fundamental kaputt ist, brechen wir ab (defensiv).
 */

#define GM_JPG_MARKER_PREFIX 0xFF
#define GM_JPG_MARKER_SOI    0xD8
#define GM_JPG_MARKER_EOI    0xD9
#define GM_JPG_MARKER_SOS    0xDA

// Hilfsfunktion: prüft, ob Buffer mit SOI beginnt
static int gm_jpg_has_valid_soi(const uint8_t *buf, size_t size) {
    if (!buf || size < 2) return 0;
    return (buf[0] == GM_JPG_MARKER_PREFIX && buf[1] == GM_JPG_MARKER_SOI);
}

// Hilfsfunktion: sucht SOS und EOI
static void gm_jpg_scan_structure(
    const uint8_t *buf,
    size_t size,
    int *has_sos,
    int *has_eoi
) {
    *has_sos = 0;
    *has_eoi = 0;

    if (!buf || size < 4) return;

    size_t pos = 0;
    while (pos + 1 < size) {
        if (buf[pos] == GM_JPG_MARKER_PREFIX) {
            uint8_t marker = buf[pos + 1];
            if (marker == GM_JPG_MARKER_SOS) {
                *has_sos = 1;
            } else if (marker == GM_JPG_MARKER_EOI) {
                *has_eoi = 1;
            }
        }
        pos++;
    }
}

/*
 * ghostmeta_rebuild_jpg:
 *
 *  clean_jpg  : Buffer, der von ghostmeta_extract_jpg_metadata erzeugt wurde
 *  clean_size : Größe dieses Buffers
 *  output_path: Zielpfad für die neue JPG-Datei
 *
 * Rückgabe:
 *  0  = OK
 * -1  = ungültige Struktur
 * -2  = IO-Fehler
 */
int ghostmeta_rebuild_jpg(
    const uint8_t *clean_jpg,
    size_t clean_size,
    const char *output_path
) {
    if (!clean_jpg || clean_size < 4 || !output_path) {
        fprintf(stderr, "[ghostmeta] rebuild_jpg: invalid arguments\n");
        return -1;
    }

    // 1) SOI prüfen
    if (!gm_jpg_has_valid_soi(clean_jpg, clean_size)) {
        fprintf(stderr, "[ghostmeta] rebuild_jpg: missing or invalid SOI\n");
        return -1;
    }

    // 2) Struktur scannen: SOS / EOI
    int has_sos = 0;
    int has_eoi = 0;
    gm_jpg_scan_structure(clean_jpg, clean_size, &has_sos, &has_eoi);

    if (!has_sos) {
        // Sehr ungewöhnlich: JPG ohne SOS → vermutlich kaputt
        fprintf(stderr, "[ghostmeta] rebuild_jpg: no SOS marker found, aborting\n");
        return -1;
    }

    // 3) Falls kein EOI vorhanden ist, ergänzen wir eines (defensiv)
    //    Wir verändern dabei NICHT die Bilddaten, sondern hängen nur EOI an,
    //    wenn der Stream sonst „offen“ wäre.
    uint8_t *final_buf = NULL;
    size_t   final_size = 0;

    if (!has_eoi) {
        final_size = clean_size + 2;
        final_buf  = (uint8_t *)malloc(final_size);
        if (!final_buf) {
            fprintf(stderr, "[ghostmeta] rebuild_jpg: malloc failed\n");
            return -2;
        }
        memcpy(final_buf, clean_jpg, clean_size);
        final_buf[clean_size]     = GM_JPG_MARKER_PREFIX;
        final_buf[clean_size + 1] = GM_JPG_MARKER_EOI;
    } else {
        // EOI ist vorhanden → wir übernehmen den Buffer 1:1
        final_size = clean_size;
        final_buf  = (uint8_t *)malloc(final_size);
        if (!final_buf) {
            fprintf(stderr, "[ghostmeta] rebuild_jpg: malloc failed\n");
            return -2;
        }
        memcpy(final_buf, clean_jpg, final_size);
    }

    // 4) Datei schreiben
    FILE *fp = fopen(output_path, "wb");
    if (!fp) {
        fprintf(stderr, "[ghostmeta] rebuild_jpg: cannot open output file '%s'\n", output_path);
        free(final_buf);
        return -2;
    }

    size_t written = fwrite(final_buf, 1, final_size, fp);
    if (written != final_size) {
        fprintf(stderr, "[ghostmeta] rebuild_jpg: fwrite failed (written=%zu, expected=%zu)\n",
                written, final_size);
        fclose(fp);
        free(final_buf);
        return -2;
    }

    fclose(fp);
    free(final_buf);

    return 0;
}
