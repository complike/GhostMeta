#ifndef GHOSTMETA_H
#define GHOSTMETA_H

#include <stdint.h>
#include <stddef.h>

typedef enum {
    GM_SEG_NO      = 0,
    GM_SEG_EMPTY   = 1,
    GM_SEG_PRESENT = 2,
    GM_SEG_CLEAN   = 3,
    GM_SEG_KEEP    = 4
} ghostmeta_segment_state_t;

typedef struct {
    uint8_t exif_before;
    uint8_t xmp_before;
    uint8_t iptc_before;
    uint8_t c2pa_before;
    uint8_t jumbf_before;
    uint8_t com_before;
    uint8_t post_eoi_before;

    uint8_t exif_after;
    uint8_t xmp_after;
    uint8_t iptc_after;
    uint8_t c2pa_after;
    uint8_t jumbf_after;
    uint8_t com_after;
    uint8_t post_eoi_after;

    size_t exif_size;
    size_t xmp_size;
    size_t iptc_size;
    size_t c2pa_size;
    size_t jumbf_size;
    size_t com_size;
    size_t post_eoi_size;
} ghostmeta_segment_info_t;

typedef struct {
    const char *report_path_json;
    const char *report_path_txt;

    const char *input_path;
    const char *output_path;

    size_t original_size;
    size_t clean_size;
    size_t removed_metadata_bytes;
    size_t post_eoi_size;

    const char *original_sha256_hex;
    const char *clean_sha256_hex;
    const char *meta_blob_sha256_hex;

    int had_exif;
    int had_c2pa;
    int had_iptc;
    int had_xmp;
    int had_jumbf;
    int had_comments;

    int had_appended_data_after_eoi;
    int reencoded_image_data;

    int total_metadata_segments_removed;

    const char *hex_head;
    const char *hex_tail;
    const char *hex_post_eoi;

    const char *parser_version;

    ghostmeta_segment_info_t seginfo;
} GhostMetaForensicContext;

int ghostmeta_write_forensic_report_json(const GhostMetaForensicContext *ctx);
int ghostmeta_write_forensic_report_txt(const GhostMetaForensicContext *ctx);

int ghostmeta_process_file(
    const char *input_path,
    const char *output_path,
    size_t *removed_bytes
);

int ghostmeta_write_audit_log(
    const char *log_path,
    const char *input_path,
    const char *output_path,
    size_t removed_bytes
);

int ghostmeta_extract_jpg_metadata(
    const uint8_t *data,
    size_t size,
    uint8_t **meta_blob,
    size_t *meta_size,
    uint8_t **clean_jpg,
    size_t *clean_size,
    ghostmeta_segment_info_t *seginfo
);

#endif
