#ifndef GHOSTENGINE_PUBLIC_H
#define GHOSTENGINE_PUBLIC_H

#include <stdint.h>
#include <stddef.h>

/*
 * GhostEngine v40 – Public API
 * 4096‑bit ARM‑NEON Pipeline
 * Dual‑Pump Core Function
 *
 * in   : pointer to input bytes
 * out  : pointer to output buffer (same length as input)
 * len  : number of bytes to process
 * seed : 8‑bit seed value for internal state initialization
 *
 * Note:
 *  - out must be pre‑allocated by the caller
 *  - processing is deterministic for a given seed
 *  - no memory is retained internally (zero‑remanence design)
 */
void ghost_core_pump_v40_dual(
    const uint8_t *in,
    uint8_t *out,
    size_t len,
    uint8_t seed
);

#endif
