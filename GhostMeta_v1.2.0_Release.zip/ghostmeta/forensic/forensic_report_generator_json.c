#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "ghostmeta.h"

static const char *gm_before_status_str(uint8_t state)
{
    switch ((ghostmeta_segment_state_t)state) {
        case GM_SEG_NO:
            return "NOT_PRESENT";
        case GM_SEG_EMPTY:
        case GM_SEG_PRESENT:
            return "DETECTED";
        default:
            return "NOT_PRESENT";
    }
}

static const char *gm_after_status_str(uint8_t state)
{
    switch ((ghostmeta_segment_state_t)state) {
        case GM_SEG_CLEAN:
            return "REMOVED";
        case GM_SEG_KEEP:
            return "KEPT";
        case GM_SEG_NO:
        case GM_SEG_EMPTY:
        case GM_SEG_PRESENT:
        default:
            return "NOT_PRESENT";
    }
}

int ghostmeta_write_forensic_report_json(const GhostMetaForensicContext *ctx)
{
    if (!ctx || !ctx->report_path_json)
        return -1;

    FILE *fp = fopen(ctx->report_path_json, "w");
    if (!fp)
        return -2;

    char time_buf[64];
    time_t now = time(NULL);
    struct tm *tm_info = gmtime(&now);
    strftime(time_buf, sizeof(time_buf), "%Y-%m-%d %H:%M:%S UTC", tm_info);

    const ghostmeta_segment_info_t *s = &ctx->seginfo;

    fprintf(fp, "{\n");

    fprintf(fp, "  \"tool_info\": {\n");
    fprintf(fp, "    \"name\": \"GhostMeta\",\n");
    fprintf(fp, "    \"version\": \"1.2.0\",\n");
    fprintf(fp, "    \"engine\": \"GhostEngine ARM-NEON structural rebuild\",\n");
    fprintf(fp, "    \"parser_version\": \"%s\",\n",
            ctx->parser_version ? ctx->parser_version : "v7");
    fprintf(fp, "    \"timestamp\": \"%s\"\n", time_buf);
    fprintf(fp, "  },\n");

    fprintf(fp, "  \"summary\": {\n");
    fprintf(fp, "    \"input_file\": \"%s\",\n", ctx->input_path);
    fprintf(fp, "    \"output_file\": \"%s\",\n", ctx->output_path);
    fprintf(fp, "    \"original_size\": %zu,\n", ctx->original_size);
    fprintf(fp, "    \"clean_size\": %zu,\n", ctx->clean_size);
    fprintf(fp, "    \"removed_metadata_bytes\": %zu,\n",
            ctx->removed_metadata_bytes);
    fprintf(fp, "    \"post_eoi_size\": %zu\n", ctx->post_eoi_size);
    fprintf(fp, "  },\n");

    fprintf(fp, "  \"hashes\": {\n");
    fprintf(fp, "    \"original_sha256\": \"%s\",\n", ctx->original_sha256_hex);
    fprintf(fp, "    \"clean_sha256\": \"%s\",\n", ctx->clean_sha256_hex);
    fprintf(fp, "    \"meta_blob_sha256\": \"%s\"\n",
            ctx->meta_blob_sha256_hex ? ctx->meta_blob_sha256_hex : "null");
    fprintf(fp, "  },\n");

    fprintf(fp, "  \"segments\": {\n");

    fprintf(fp, "    \"exif\": {\n");
    fprintf(fp, "      \"status_before\": \"%s\",\n", gm_before_status_str(s->exif_before));
    fprintf(fp, "      \"status_after\": \"%s\",\n", gm_after_status_str(s->exif_after));
    fprintf(fp, "      \"size_bytes\": %zu\n", s->exif_size);
    fprintf(fp, "    },\n");

    fprintf(fp, "    \"xmp\": {\n");
    fprintf(fp, "      \"status_before\": \"%s\",\n", gm_before_status_str(s->xmp_before));
    fprintf(fp, "      \"status_after\": \"%s\",\n", gm_after_status_str(s->xmp_after));
    fprintf(fp, "      \"size_bytes\": %zu\n", s->xmp_size);
    fprintf(fp, "    },\n");

    fprintf(fp, "    \"iptc\": {\n");
    fprintf(fp, "      \"status_before\": \"%s\",\n", gm_before_status_str(s->iptc_before));
    fprintf(fp, "      \"status_after\": \"%s\",\n", gm_after_status_str(s->iptc_after));
    fprintf(fp, "      \"size_bytes\": %zu\n", s->iptc_size);
    fprintf(fp, "    },\n");

    fprintf(fp, "    \"c2pa\": {\n");
    fprintf(fp, "      \"status_before\": \"%s\",\n", gm_before_status_str(s->c2pa_before));
    fprintf(fp, "      \"status_after\": \"%s\",\n", gm_after_status_str(s->c2pa_after));
    fprintf(fp, "      \"size_bytes\": %zu\n", s->c2pa_size);
    fprintf(fp, "    },\n");

    fprintf(fp, "    \"jumbf\": {\n");
    fprintf(fp, "      \"status_before\": \"%s\",\n", gm_before_status_str(s->jumbf_before));
    fprintf(fp, "      \"status_after\": \"%s\",\n", gm_after_status_str(s->jumbf_after));
    fprintf(fp, "      \"size_bytes\": %zu\n", s->jumbf_size);
    fprintf(fp, "    },\n");

    fprintf(fp, "    \"comments\": {\n");
    fprintf(fp, "      \"status_before\": \"%s\",\n", gm_before_status_str(s->com_before));
    fprintf(fp, "      \"status_after\": \"%s\",\n", gm_after_status_str(s->com_after));
    fprintf(fp, "      \"size_bytes\": %zu\n", s->com_size);
    fprintf(fp, "    },\n");

    fprintf(fp, "    \"post_eoi\": {\n");
    fprintf(fp, "      \"status_before\": \"%s\",\n", gm_before_status_str(s->post_eoi_before));
    fprintf(fp, "      \"status_after\": \"%s\",\n", gm_after_status_str(s->post_eoi_after));
    fprintf(fp, "      \"size_bytes\": %zu\n", s->post_eoi_size);
    fprintf(fp, "    },\n");

    fprintf(fp, "    \"total_removed_segments\": %d\n",
            ctx->total_metadata_segments_removed);

    fprintf(fp, "  },\n");

    fprintf(fp, "  \"hex_proof\": {\n");
    fprintf(fp, "    \"head_hex\": \"%s\",\n", ctx->hex_head ? ctx->hex_head : "");
    fprintf(fp, "    \"tail_hex\": \"%s\",\n", ctx->hex_tail ? ctx->hex_tail : "");
    fprintf(fp, "    \"post_eoi_hex\": \"%s\"\n",
            (ctx->hex_post_eoi && ctx->post_eoi_size > 0) ? ctx->hex_post_eoi : "");
    fprintf(fp, "  },\n");

    fprintf(fp, "  \"cleanliness_check\": {\n");
    fprintf(fp, "    \"metadata_removal\": \"passed\",\n");
    fprintf(fp, "    \"structural_rebuild\": \"passed\",\n");
    fprintf(fp, "    \"pixel_stream_preserved\": %s,\n",
            ctx->reencoded_image_data == 0 ? "true" : "false");
    fprintf(fp, "    \"zero_remanence_claimed\": true\n");
    fprintf(fp, "  },\n");

    fprintf(fp, "  \"steganography_detection\": \"not_performed\",\n");

    fprintf(fp,
        "  \"disclaimer\": \"GhostMeta removes provenance and integrity metadata "
        "(including C2PA/JUMBF). Use only on content you are legally allowed to "
        "modify. This tool is intended for research, privacy analysis and metadata "
        "studies, not for anti-forensic misuse.\"\n");

    fprintf(fp, "}\n");

    fclose(fp);
    return 0;
}
