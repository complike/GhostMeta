#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "ghostmeta.h"

static void gm_format_hex_block(FILE *fp, const char *hex)
{
    if (!hex || hex[0] == '\0') {
        fprintf(fp, "  N/A\n");
        return;
    }

    size_t len = strlen(hex);
    for (size_t i = 0; i < len; i++) {
        fputc(hex[i], fp);
        if ((i + 1) % 64 == 0 && (i + 1) < len)
            fprintf(fp, "\n ");
    }
    fprintf(fp, "\n");
}

static const char *gm_before_status_str(uint8_t state)
{
    switch ((ghostmeta_segment_state_t)state) {
        case GM_SEG_NO:
            return "NOT_PRESENT";
        case GM_SEG_EMPTY:
        case GM_SEG_PRESENT:
            return "DETECTED";
        default:
            return "NOT_PRESENT";
    }
}

static const char *gm_after_status_str(uint8_t state)
{
    switch ((ghostmeta_segment_state_t)state) {
        case GM_SEG_CLEAN:
            return "REMOVED";
        case GM_SEG_KEEP:
            return "KEPT";
        case GM_SEG_NO:
        case GM_SEG_EMPTY:
        case GM_SEG_PRESENT:
        default:
            return "NOT_PRESENT";
    }
}

int ghostmeta_write_forensic_report_txt(const GhostMetaForensicContext *ctx)
{
    if (!ctx || !ctx->report_path_txt)
        return -1;

    FILE *fp = fopen(ctx->report_path_txt, "w");
    if (!fp)
        return -2;

    char time_buf[64];
    time_t now = time(NULL);
    struct tm *tm_info = gmtime(&now);
    strftime(time_buf, sizeof(time_buf), "%Y-%m-%d %H:%M:%S UTC", tm_info);

    const ghostmeta_segment_info_t *s = &ctx->seginfo;

    fprintf(fp,
        "┌───────────────────────────────────────────────────────────────┐\n"
        "│           GHOSTMETA – METADATA REMOVAL REPORT                 │\n"
        "│        Structural Metadata Removal & Integrity Analysis        │\n"
        "│        Timestamp: %s                      │\n"
        "└───────────────────────────────────────────────────────────────┘\n\n",
        time_buf
    );

    fprintf(fp,
        "[1] FILE INFORMATION\n"
        "-----------------------------------------------------------------\n"
        " Input File      : %s\n"
        " Output File     : %s\n\n"
        " Original Size   : %zu Bytes\n"
        " Clean Size      : %zu Bytes\n"
        " Removed Bytes   : %zu Bytes\n"
        " Post-EOI Data   : %zu Bytes\n"
        " Parser Version  : %s\n"
        " Status          : SUCCESS (Structural Rebuild, No Re-encoding)\n\n",
        ctx->input_path,
        ctx->output_path,
        ctx->original_size,
        ctx->clean_size,
        ctx->removed_metadata_bytes,
        ctx->post_eoi_size,
        ctx->parser_version ? ctx->parser_version : "unknown"
    );

    fprintf(fp,
        "[2] CRYPTOGRAPHIC HASHES\n"
        "-----------------------------------------------------------------\n"
        " Original SHA-256 : %s\n"
        " Clean SHA-256    : %s\n"
        " Meta-Blob SHA256 : %s\n\n",
        ctx->original_sha256_hex,
        ctx->clean_sha256_hex,
        ctx->meta_blob_sha256_hex ? ctx->meta_blob_sha256_hex : "N/A"
    );

    fprintf(fp,
        "[3] METADATA SEGMENT MATRIX\n"
        "-----------------------------------------------------------------\n"
        " Segment Type                Before (size)           After\n"
        " ---------------------------------------------------------------\n"
        " EXIF (APP1)                 %-10s (%8zu B)   %-10s\n"
        " C2PA / JUMBF (APP11)        %-10s (%8zu B)   %-10s\n"
        " IPTC (APP13)                %-10s (%8zu B)   %-10s\n"
        " XMP (APP1)                  %-10s (%8zu B)   %-10s\n"
        " Raw JUMBF Boxes             %-10s (%8zu B)   %-10s\n"
        " Comment Segments (COM)      %-10s (%8zu B)   %-10s\n"
        " Appended Data (Post-EOI)    %-10s (%8zu B)   %-10s\n\n"
        " Total Removed Segment Types : %d\n\n",
        gm_before_status_str(s->exif_before),   s->exif_size,   gm_after_status_str(s->exif_after),
        gm_before_status_str(s->c2pa_before),   s->c2pa_size,   gm_after_status_str(s->c2pa_after),
        gm_before_status_str(s->iptc_before),   s->iptc_size,   gm_after_status_str(s->iptc_after),
        gm_before_status_str(s->xmp_before),    s->xmp_size,    gm_after_status_str(s->xmp_after),
        gm_before_status_str(s->jumbf_before),  s->jumbf_size,  gm_after_status_str(s->jumbf_after),
        gm_before_status_str(s->com_before),    s->com_size,    gm_after_status_str(s->com_after),
        gm_before_status_str(s->post_eoi_before), s->post_eoi_size, gm_after_status_str(s->post_eoi_after),
        ctx->total_metadata_segments_removed
    );

    if (ctx->total_metadata_segments_removed == 0) {
        fprintf(fp,
            " Note: No removable metadata structures were detected in this file.\n"
            "       Pixel payload untouched.\n\n"
        );
    } else {
        fprintf(fp,
            " Note: Metadata structures were detected and removed as indicated above.\n"
            "       Pixel payload untouched.\n\n"
        );
    }

    fprintf(fp,
        "[4] INTEGRITY HEX ANCHORS\n"
        "-----------------------------------------------------------------\n"
        " Head Hex (first 256 bytes of clean JPEG):\n"
        " ----------------------------------------------------------------\n "
    );
    gm_format_hex_block(fp, ctx->hex_head);

    fprintf(fp,
        "\n Tail Hex (last 256 bytes of clean JPEG):\n"
        " ----------------------------------------------------------------\n "
    );
    gm_format_hex_block(fp, ctx->hex_tail);

    fprintf(fp,
        "\n Post-EOI Hex (data after EOI in original file, up to 256 bytes):\n"
        " ----------------------------------------------------------------\n "
    );
    if (ctx->post_eoi_size > 0)
        gm_format_hex_block(fp, ctx->hex_post_eoi);
    else
        fprintf(fp, "  None (no data after EOI)\n\n");

    fprintf(fp,
        " Note: These hex anchors allow independent verification of the\n"
        "       first and last bytes of the cleaned JPEG and the absence\n"
        "       of hidden data after EOI.\n\n"
    );

    fprintf(fp,
        "[5] PROCESSING MODEL\n"
        "-----------------------------------------------------------------\n"
        " Mode            : Structural Rebuild\n"
        " Re-encoding     : Disabled (Huffman stream preserved)\n"
        " Pixel Data      : Unchanged\n"
        " Metadata        : Fully removed (APPx, COM, JUMBF/C2PA)\n\n"
    );

    fprintf(fp,
        "[6] CLEANLINESS CHECK\n"
        "-----------------------------------------------------------------\n"
        " Metadata Removal Integrity     : PASSED (internal validation)\n"
        " Structural Rebuild Consistency : PASSED\n"
        " Pixel Stream Preservation      : PASSED\n"
        " Zero-Remanence                 : implementation follows non-\n"
        "                                  persistence principles (no\n"
        "                                  runtime RAM verification)\n\n"
    );

    fprintf(fp,
        "[7] METHODOLOGY\n"
        "-----------------------------------------------------------------\n"
        " GhostMeta Parser v7 performs structural JPEG rebuild without\n"
        " re-encoding. Only header and metadata segments are modified;\n"
        " the compressed pixel stream remains unchanged. The\n"
        " implementation follows zero-remanence principles (no global\n"
        " variables, no static buffers, no persistent memory). This\n"
        " report does not verify RAM state at runtime; it documents\n"
        " design properties, not live memory forensics. Steganographic\n"
        " payloads embedded in pixel data are not detected or modified.\n\n"
    );

    fprintf(fp,
        "[8] LEGAL & ETHICAL NOTE\n"
        "-----------------------------------------------------------------\n"
        " GhostMeta removes provenance and integrity metadata (including\n"
        " C2PA/JUMBF). Use only on content you are legally allowed to\n"
        " modify. This tool is intended for research, privacy analysis\n"
        " and metadata studies, not for anti-forensic misuse.\n\n"
        "=== END OF REPORT ===\n"
    );

    fclose(fp);
    return 0;
}
