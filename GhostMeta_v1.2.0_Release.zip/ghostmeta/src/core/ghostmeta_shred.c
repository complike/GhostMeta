// ghostmeta_shred.c
// Bridge zwischen GhostMeta und der 4096‑bit GhostEngine (libghostengine.a)

#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include "ghostmeta.h"
#include "ghostengine_public.h"

// Basis‑Wrapper: direkter Aufruf der Engine
void ghostmeta_engine_pump_v40_dual(const uint8_t *in,
                                    uint8_t *out,
                                    size_t len,
                                    uint8_t seed)
{
    if (!in || !out || len == 0)
        return;

    // 4096‑bit / NEON‑Engine
    ghost_core_pump_v40_dual(in, out, len, seed);
}

// Komfort‑Wrapper: fester Seed (z.B. 0x19) für deterministische Nutzung
void ghostmeta_engine_pump_default(const uint8_t *in,
                                   uint8_t *out,
                                   size_t len)
{
    // Standard‑Seed – kannst du später zentral in ghostmeta.h definieren
    const uint8_t seed = 0x19;
    ghostmeta_engine_pump_v40_dual(in, out, len, seed);
}

// Optional: Allokierender Wrapper – erzeugt einen neuen Buffer
// Rückgabewert: 0 = OK, <0 = Fehler
int ghostmeta_engine_pump_alloc(const uint8_t *in,
                                size_t len,
                                uint8_t **out_buf)
{
    if (!in || !out_buf || len == 0)
        return -1;

    uint8_t *buf = (uint8_t *)malloc(len);
    if (!buf)
        return -2;

    ghostmeta_engine_pump_default(in, buf, len);
    *out_buf = buf;
    return 0;
}
