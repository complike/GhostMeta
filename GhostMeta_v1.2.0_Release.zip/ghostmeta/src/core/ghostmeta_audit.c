#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "ghostmeta.h"

static void gm_get_iso_timestamp(char *buf, size_t size) {
    time_t now = time(NULL);
    struct tm *utc = gmtime(&now);
    strftime(buf, size, "%Y-%m-%dT%H:%M:%SZ", utc);
}

int ghostmeta_write_audit_log(
    const char *log_path,
    const char *input_path,
    const char *output_path,
    size_t removed_bytes
) {
    if (!log_path || !input_path || !output_path) {
        return 1;
    }

    FILE *fp = fopen(log_path, "w");
    if (!fp) {
        fprintf(stderr, "[ghostmeta] cannot write audit file '%s'\n", log_path);
        return 3;
    }

    char timestamp[64];
    gm_get_iso_timestamp(timestamp, sizeof(timestamp));

    fprintf(fp, "{\n");
    fprintf(fp, "  \"ghostmeta_version\": \"1.2.0\",\n");
    fprintf(fp, "  \"timestamp\": \"%s\",\n", timestamp);
    fprintf(fp, "  \"input_file\": \"%s\",\n", input_path);
    fprintf(fp, "  \"output_file\": \"%s\",\n", output_path);
    fprintf(fp, "  \"removed_metadata_bytes\": %zu,\n", removed_bytes);
    fprintf(fp, "  \"profile\": \"secure\"\n");
    fprintf(fp, "}\n");

    fclose(fp);
    return 0;
}
