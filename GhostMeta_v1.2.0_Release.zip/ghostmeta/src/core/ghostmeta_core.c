#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <libgen.h>
#include <CommonCrypto/CommonDigest.h>
#include "ghostmeta.h"

/* ---------------------------------------------------------
 * SHA-256 → Hex
 * --------------------------------------------------------- */
static void gm_sha256_hex(const uint8_t *buf, size_t size, char out_hex[65]) {
    unsigned char hash[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256(buf, (CC_LONG)size, hash);

    for (int i = 0; i < CC_SHA256_DIGEST_LENGTH; i++) {
        sprintf(out_hex + (i * 2), "%02x", hash[i]);
    }
    out_hex[64] = '\0';
}

/* ---------------------------------------------------------
 * Hex-Snippet (Head/Tail)
 * --------------------------------------------------------- */
static char *gm_hex_snippet(const uint8_t *buf, size_t size, size_t count) {
    if (!buf || size == 0) return NULL;

    size_t n = (size < count) ? size : count;
    char *out = malloc(n * 2 + 1);
    if (!out) return NULL;

    for (size_t i = 0; i < n; i++) {
        sprintf(out + (i * 2), "%02x", buf[i]);
    }
    out[n * 2] = '\0';
    return out;
}

/* ---------------------------------------------------------
 * Post-EOI Hex
 * --------------------------------------------------------- */
static char *gm_hex_post_eoi(
    const uint8_t *buf,
    size_t size,
    size_t *post_eoi_size_out
) {
    if (!buf || size < 2) {
        if (post_eoi_size_out) *post_eoi_size_out = 0;
        return NULL;
    }

    ssize_t last_eoi = -1;
    for (ssize_t i = (ssize_t)size - 2; i >= 0; i--) {
        if (buf[i] == 0xFF && buf[i + 1] == 0xD9) {
            last_eoi = i;
            break;
        }
    }

    if (last_eoi < 0 || (size_t)(last_eoi + 2) >= size) {
        if (post_eoi_size_out) *post_eoi_size_out = 0;
        return NULL;
    }

    size_t post_size = size - (size_t)(last_eoi + 2);
    if (post_eoi_size_out) *post_eoi_size_out = post_size;

    size_t n = (post_size < 256) ? post_size : 256;
    char *out = malloc(n * 2 + 1);
    if (!out) return NULL;

    const uint8_t *p = buf + last_eoi + 2;
    for (size_t i = 0; i < n; i++) {
        sprintf(out + (i * 2), "%02x", p[i]);
    }
    out[n * 2] = '\0';
    return out;
}

/* ---------------------------------------------------------
 * JPG-Erkennung
 * --------------------------------------------------------- */
static int gm_is_jpeg(const char *path) {
    const char *dot = strrchr(path, '.');
    if (!dot) return 0;
    if (!strcasecmp(dot, ".jpg"))  return 1;
    if (!strcasecmp(dot, ".jpeg")) return 1;
    return 0;
}

/* ---------------------------------------------------------
 * Datei komplett einlesen
 * --------------------------------------------------------- */
static int gm_read_file(const char *path, uint8_t **buf, size_t *size) {
    *buf = NULL;
    *size = 0;

    FILE *fp = fopen(path, "rb");
    if (!fp) {
        fprintf(stderr, "[ghostmeta] cannot open input '%s'\n", path);
        return 3; /* I/O error */
    }

    fseek(fp, 0, SEEK_END);
    long len = ftell(fp);
    if (len < 0) {
        fclose(fp);
        return 3;
    }
    rewind(fp);

    uint8_t *tmp = malloc((size_t)len);
    if (!tmp) {
        fclose(fp);
        fprintf(stderr, "[ghostmeta] malloc failed (%ld bytes)\n", len);
        return 3;
    }

    size_t rd = fread(tmp, 1, (size_t)len, fp);
    fclose(fp);

    if (rd != (size_t)len) {
        fprintf(stderr, "[ghostmeta] read error on '%s'\n", path);
        free(tmp);
        return 3;
    }

    *buf  = tmp;
    *size = (size_t)len;
    return 0;
}

/* ---------------------------------------------------------
 * Datei schreiben
 * --------------------------------------------------------- */
static int gm_write_file(const char *path, const uint8_t *buf, size_t size) {
    FILE *fp = fopen(path, "wb");
    if (!fp) {
        fprintf(stderr, "[ghostmeta] cannot write output '%s'\n", path);
        return 3;
    }

    size_t wr = fwrite(buf, 1, size, fp);
    fclose(fp);

    if (wr != size) {
        fprintf(stderr, "[ghostmeta] write error on '%s'\n", path);
        return 3;
    }
    return 0;
}

/* ---------------------------------------------------------
 * Mapping BEFORE-State → JSON-Status
 * --------------------------------------------------------- */
static const char *gm_before_status_str(uint8_t state)
{
    switch ((ghostmeta_segment_state_t)state) {
        case GM_SEG_NO:
            return "NOT_PRESENT";
        case GM_SEG_EMPTY:
        case GM_SEG_PRESENT:
            return "DETECTED";
        default:
            return "NOT_PRESENT";
    }
}

/* ---------------------------------------------------------
 * Mapping AFTER-State → JSON-Status
 * --------------------------------------------------------- */
static const char *gm_after_status_str(uint8_t state)
{
    switch ((ghostmeta_segment_state_t)state) {
        case GM_SEG_CLEAN:
            return "REMOVED";
        case GM_SEG_KEEP:
            return "KEPT";
        case GM_SEG_NO:
        case GM_SEG_EMPTY:
        case GM_SEG_PRESENT:
        default:
            return "NOT_PRESENT";
    }
}

/* ---------------------------------------------------------
 * HAUPTFUNKTION
 * --------------------------------------------------------- */
int ghostmeta_process_file(
    const char *input_path,
    const char *output_path,
    size_t *removed_bytes
) {
    *removed_bytes = 0;

    uint8_t *in_buf  = NULL;
    size_t   in_size = 0;

    if (gm_read_file(input_path, &in_buf, &in_size) != 0) {
        return 3;
    }

    if (!gm_is_jpeg(input_path)) {
        free(in_buf);
        return 2; /* unsupported format */
    }

    uint8_t *meta_blob  = NULL;
    size_t   meta_size  = 0;
    uint8_t *clean_jpg  = NULL;
    size_t   clean_size = 0;

    ghostmeta_segment_info_t seginfo;
    memset(&seginfo, 0, sizeof(seginfo));

    int rc = ghostmeta_extract_jpg_metadata(
        in_buf,
        in_size,
        &meta_blob,
        &meta_size,
        &clean_jpg,
        &clean_size,
        &seginfo
    );

    if (rc != 0 || !clean_jpg || clean_size == 0) {
        fprintf(stderr, "[ghostmeta] JPG parser failed → raw copy\n");

        int w = gm_write_file(output_path, in_buf, in_size);
        free(in_buf);
        if (meta_blob) free(meta_blob);

        return (w == 0) ? 0 : 3;
    }

    if (gm_write_file(output_path, clean_jpg, clean_size) != 0) {
        free(in_buf);
        free(clean_jpg);
        if (meta_blob) free(meta_blob);
        return 3;
    }

    *removed_bytes = (in_size > clean_size) ? (in_size - clean_size) : 0;

    GhostMetaForensicContext ctx;
    memset(&ctx, 0, sizeof(ctx));

    char *path_json = NULL;
    char *path_txt  = NULL;

    {
        char *path_copy = strdup(input_path);
        char *base_copy = strdup(input_path);

        char *dir  = dirname(path_copy);
        char *file = basename(base_copy);

        size_t len_json = strlen(dir) + strlen(file) + 32;
        size_t len_txt  = strlen(dir) + strlen(file) + 32;

        path_json = malloc(len_json);
        path_txt  = malloc(len_txt);

        snprintf(path_json, len_json, "%s/%s.forensic.json", dir, file);
        snprintf(path_txt,  len_txt,  "%s/%s.forensic.txt",  dir, file);

        free(path_copy);
        free(base_copy);
    }

    ctx.report_path_json = path_json;
    ctx.report_path_txt  = path_txt;

    ctx.input_path  = input_path;
    ctx.output_path = output_path;

    ctx.original_size = in_size;
    ctx.clean_size    = clean_size;
    ctx.removed_metadata_bytes = *removed_bytes;

    static char sha_in[65], sha_out[65], sha_meta[65];
    gm_sha256_hex(in_buf, in_size, sha_in);
    gm_sha256_hex(clean_jpg, clean_size, sha_out);
    if (meta_blob && meta_size > 0)
        gm_sha256_hex(meta_blob, meta_size, sha_meta);

    ctx.original_sha256_hex  = sha_in;
    ctx.clean_sha256_hex     = sha_out;
    ctx.meta_blob_sha256_hex = (meta_blob && meta_size > 0) ? sha_meta : NULL;

    ctx.hex_head = gm_hex_snippet(clean_jpg, clean_size, 256);
    ctx.hex_tail = gm_hex_snippet(
        clean_jpg + (clean_size > 256 ? clean_size - 256 : 0),
        (clean_size > 256 ? 256 : clean_size),
        (clean_size > 256 ? 256 : clean_size)
    );

    ctx.hex_post_eoi = gm_hex_post_eoi(in_buf, in_size, &ctx.post_eoi_size);
    ctx.had_appended_data_after_eoi = (ctx.post_eoi_size > 0);

    /* Segment-Info übernehmen */
    ctx.seginfo = seginfo;

    /* Alte Flags aus BEFORE ableiten (für einfache Anzeige) */
    ctx.had_exif     = (seginfo.exif_before  != GM_SEG_NO);
    ctx.had_c2pa     = (seginfo.c2pa_before  != GM_SEG_NO);
    ctx.had_iptc     = (seginfo.iptc_before  != GM_SEG_NO);
    ctx.had_xmp      = (seginfo.xmp_before   != GM_SEG_NO);
    ctx.had_jumbf    = (seginfo.jumbf_before != GM_SEG_NO);
    ctx.had_comments = (seginfo.com_before   != GM_SEG_NO);

    ctx.reencoded_image_data = 0;

    int total_removed = 0;
    if (seginfo.exif_after  == GM_SEG_CLEAN) total_removed++;
    if (seginfo.c2pa_after  == GM_SEG_CLEAN) total_removed++;
    if (seginfo.iptc_after  == GM_SEG_CLEAN) total_removed++;
    if (seginfo.xmp_after   == GM_SEG_CLEAN) total_removed++;
    if (seginfo.jumbf_after == GM_SEG_CLEAN) total_removed++;
    if (seginfo.com_after   == GM_SEG_CLEAN) total_removed++;
    if (seginfo.post_eoi_after == GM_SEG_CLEAN) total_removed++;

    ctx.total_metadata_segments_removed = total_removed;
    ctx.parser_version = "v7";

    ghostmeta_write_forensic_report_json(&ctx);
    ghostmeta_write_forensic_report_txt(&ctx);

    free(path_json);
    free(path_txt);

    free(in_buf);
    free(clean_jpg);
    if (meta_blob) free(meta_blob);
    if (ctx.hex_head)     free((void*)ctx.hex_head);
    if (ctx.hex_tail)     free((void*)ctx.hex_tail);
    if (ctx.hex_post_eoi) free((void*)ctx.hex_post_eoi);

    return 0;
}
