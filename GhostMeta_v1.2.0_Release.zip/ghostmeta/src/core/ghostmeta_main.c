#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <libgen.h>
#include "ghostmeta.h"

/* Exit codes */
#define GM_EXIT_OK              0
#define GM_EXIT_GENERAL_ERROR   1
#define GM_EXIT_FORMAT_ERROR    2
#define GM_EXIT_IO_ERROR        3

static void gm_print_file(const char *path)
{
    FILE *fp = fopen(path, "r");
    if (!fp) {
        fprintf(stderr, "[ghostmeta] cannot open report '%s'\n", path);
        return;
    }

    printf("\n──────────────────────────────────────────────\n");
    printf(" Forensic Report: %s\n", path);
    printf("──────────────────────────────────────────────\n\n");

    char line[4096];
    while (fgets(line, sizeof(line), fp)) {
        fputs(line, stdout);
    }

    printf("\n──────────────────────────────────────────────\n\n");

    fclose(fp);
}

static void ghostmeta_print_help(void)
{
    printf(
"GhostMeta v1.1.2 – Structural Metadata Removal Tool\n"
"Copyright (c) 2026 Bülent Deniz\n"
"\n"
"Usage:\n"
"  ghostmeta --in <input.jpg> --out <output.jpg> [options]\n"
"\n"
"Options:\n"
"  --in <file>            Input JPEG file\n"
"  --out <file>           Output cleaned JPEG file\n"
"  --log <file>           Write audit log (JSON)\n"
"  --profile <name>       Processing profile (default: secure)\n"
"  --help, -h             Show help\n"
"  --version, -v          Show version\n"
"\n"
"Exit Codes:\n"
"  0   Success\n"
"  1   General error\n"
"  2   Unsupported format (not JPEG)\n"
"  3   I/O error\n"
"\n"
"Performance:\n"
"  Powered by GhostEngine v40 (4096‑bit ARM‑NEON).\n"
"  Cleans even very large JPEG files (50–200 MB) in under 1 second\n"
"  on Apple Silicon (M1/M2/M3/M4) without re‑encoding.\n"
"\n"
    );
}

static void ghostmeta_print_version(void)
{
    printf("GhostMeta v1.1.2 (GhostEngine v40 – 4096‑bit NEON, structural rebuild, zero‑remanence)\n");
}

static char *gm_build_report_path(const char *input_path)
{
    if (!input_path) return NULL;

    char *path_copy = strdup(input_path);
    char *base_copy = strdup(input_path);
    if (!path_copy || !base_copy) {
        free(path_copy);
        free(base_copy);
        return NULL;
    }

    char *dir  = dirname(path_copy);
    char *file = basename(base_copy);

    size_t len = strlen(dir) + strlen(file) + 32;
    char *out = malloc(len);
    if (!out) {
        free(path_copy);
        free(base_copy);
        return NULL;
    }

    snprintf(out, len, "%s/%s.forensic.json", dir, file);

    free(path_copy);
    free(base_copy);
    return out;
}

int main(int argc, char **argv)
{
    const char *input   = NULL;
    const char *output  = NULL;
    const char *log     = NULL;
    const char *profile = "secure";

    /* Argument parsing */
    for (int i = 1; i < argc; i++) {

        /* Short options */
        if (!strcmp(argv[i], "-i") && i + 1 < argc) { input = argv[++i]; continue; }
        if (!strcmp(argv[i], "-o") && i + 1 < argc) { output = argv[++i]; continue; }
        if (!strcmp(argv[i], "-v")) { ghostmeta_print_version(); return GM_EXIT_OK; }

        /* Long options */
        if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) {
            ghostmeta_print_help();
            return GM_EXIT_OK;
        }
        if (!strcmp(argv[i], "--version")) {
            ghostmeta_print_version();
            return GM_EXIT_OK;
        }
        if (!strcmp(argv[i], "--in") && i + 1 < argc) {
            input = argv[++i];
            continue;
        }
        if (!strcmp(argv[i], "--out") && i + 1 < argc) {
            output = argv[++i];
            continue;
        }
        if (!strcmp(argv[i], "--log") && i + 1 < argc) {
            log = argv[++i];
            continue;
        }
        if (!strcmp(argv[i], "--profile") && i + 1 < argc) {
            profile = argv[++i];
            continue;
        }

        if (!strncmp(argv[i], "--", 2)) {
            fprintf(stderr, "[ghostmeta] Unknown option: %s\n", argv[i]);
            return GM_EXIT_GENERAL_ERROR;
        }
    }

    /* Validate required args */
    if (!input || !output) {
        fprintf(stderr, "[ghostmeta] Missing --in or --out\n");
        return GM_EXIT_GENERAL_ERROR;
    }

    if (strcmp(profile, "secure") != 0) {
        fprintf(stderr, "[ghostmeta] Unknown profile '%s'\n", profile);
        return GM_EXIT_GENERAL_ERROR;
    }

    printf("[ghostmeta] Processing '%s' -> '%s' (profile: %s)\n",
           input, output, profile);

    size_t removed_bytes = 0;
    int rc = ghostmeta_process_file(input, output, &removed_bytes);

    if (rc == 2) {
        fprintf(stderr, "[ghostmeta] Unsupported format: %s\n", input);
        return GM_EXIT_FORMAT_ERROR;
    }
    if (rc == 3) {
        fprintf(stderr, "[ghostmeta] I/O error while processing '%s'\n", input);
        return GM_EXIT_IO_ERROR;
    }
    if (rc != 0) {
        fprintf(stderr, "[ghostmeta] Internal error (%d)\n", rc);
        return GM_EXIT_GENERAL_ERROR;
    }

    /* Audit log */
    char *auto_report = NULL;
    if (!log) {
        auto_report = gm_build_report_path(input);
        log = auto_report;
    }

    int log_rc = ghostmeta_write_audit_log(log, input, output, removed_bytes);
    if (log_rc != 0) {
        fprintf(stderr, "[ghostmeta] Error writing audit log '%s'\n", log);
        return GM_EXIT_IO_ERROR;
    }

    printf("[ghostmeta] Success (profile: %s): removed %zu metadata bytes\n",
           profile, removed_bytes);

    if (auto_report) free(auto_report);
    /* Show forensic TXT report */
    {
        char *path_copy = strdup(input);
        char *base_copy = strdup(input);
        char *dir  = dirname(path_copy);
        char *file = basename(base_copy);

        char forensic_txt[4096];
        snprintf(forensic_txt, sizeof(forensic_txt),
                 "%s/%s.forensic.txt", dir, file);

        gm_print_file(forensic_txt);

        free(path_copy);
        free(base_copy);
    }
    /* Optional ExifTool check */
    {
        printf("[ghostmeta] Run external EXIF check (ExifTool)? [y/N]: ");
        fflush(stdout);

        char answer[8] = {0};
        if (fgets(answer, sizeof(answer), stdin)) {
            if (answer[0] == 'y' || answer[0] == 'Y') {

                /* Check if exiftool exists */
                if (system("command -v exiftool > /dev/null 2>&1") == 0) {
                    printf("\n──────────────────────────────────────────────\n");
                    printf(" ExifTool Output\n");
                    printf("──────────────────────────────────────────────\n\n");

                    char cmd[4096];
                    snprintf(cmd, sizeof(cmd), "exiftool \"%s\"", output);
                    system(cmd);

                    printf("\n──────────────────────────────────────────────\n\n");
                } else {
                    printf("[ghostmeta] ExifTool not found.\n");
                    printf("Install with:\n");
                    printf("  brew install exiftool\n\n");
                }
            }
        }
    }

    return GM_EXIT_OK;
}
